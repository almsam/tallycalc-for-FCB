//
//  Posted Loads.swift
//  The Board
//
//  Created by Rad almuallim on 2017-10-06.
//  Copyright © 2017 Forest Commodities Board Inc. All rights reserved.
//

import UIKit
import Foundation

class PostedLoads : UIViewController {
    
    let attemtedUrl = URL(string: "http://66.70.179.204/PHPforMobile/ValidateUser4.php?email=" + username.text! + "&password=" + pass)

}
