//
//  ViewController.swift
//  Advanced segues
//
//  Created by Rad almuallim on 2017-03-10.
//  Copyright © 2017 Rad almuallim. All rights reserved.
//

import UIKit

var rowCounter:Int = 0

class ViewController: UIViewController {

    override func viewDidLoad() {
        
        print(rowCounter)
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

