//
//  NaviController.swift
//  FCB TallyCalc
//
//  Created by Rad almuallim on 2018-07-18.
//  Copyright © 2018 Forest Commodities Board Inc. All rights reserved.
//

import UIKit

class NaviController: UINavigationController {
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
    }
    
}
